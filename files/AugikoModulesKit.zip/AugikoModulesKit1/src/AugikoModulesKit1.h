#ifndef _AUGIKOMODULESKIT1_H_
#define _AUGIKOMODULESKIT1_H_

#include "I2CDev/I2Cdev.h"      // I2C Library
#include "I2CDev/MPU6050.h"     // Accel & Gyro Sensor Library
#include "IRremote/IRremote.h"  // IR Remote Controller

#endif/*_AUGIKOMODULESKIT1_H_*/
