#ifndef _AUGIKOMODULESKIT1_H_
#define _AUGIKOMODULESKIT1_H_

// Additional library IRremote is required by the Augiko Sensor Module Kit
// Please refer to the document Augiko Sensor Module Kit 1 User Guide, 
// Chapter 9.3 Install Additional Library for more details.
// 
// Install the IRremote library via Library Manager
// if using the Arduino IDE, click here: http://librarymanager#IRremote
#include "IRremote.h"   // IR Remote Controller

#endif/*_AUGIKOMODULESKIT1_H_*/
